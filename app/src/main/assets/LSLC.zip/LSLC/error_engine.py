class ErrorEngine:
    # ANSI Color Codes
    RED = '\033[91m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

    @staticmethod
    def report(line_num, error_type, line_text, help_text):
        """
        Outputs a highly formatted, colorized error message.
        """
        print(f"\n\n\t> {ErrorEngine.CYAN}Line: {line_num}{ErrorEngine.RESET}")
        print(f"\t> {ErrorEngine.BOLD}{ErrorEngine.RED}[{error_type}] ERROR:{ErrorEngine.RESET} {line_text}")
        print(f"\t> {ErrorEngine.YELLOW}Help: {help_text}{ErrorEngine.RESET}\n\n")