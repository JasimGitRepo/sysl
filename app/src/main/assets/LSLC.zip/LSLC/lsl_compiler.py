import sys
import os
from lsl_parser import LSLParser

def compile_file(input_path):
    output_path = input_path.replace('.lsl', '.yml')
    parser = LSLParser("lsl_syntax.json")
    compiled_yaml = []
    has_errors = False

    print(f"[*] Compiling {os.path.basename(input_path)}...")

    with open(input_path, 'r') as f:
        lines = f.readlines()

    for idx, line in enumerate(lines):
        line_num = idx + 1
        
        # Skip empty lines
        if not line.strip() or line.strip().startswith('#'):
            continue
            
        yaml_block = parser.parse_line(line, line_num)
        
        if yaml_block is None:
            # Error encountered, flag it and stop accumulating
            has_errors = True
            break
        elif yaml_block != "":
            compiled_yaml.append(yaml_block)

    if has_errors:
        print(f"\033[91m[X] Compilation Aborted due to errors.\033[0m")
        sys.exit(1)
        
    # Write success
    with open(output_path, 'w') as f:
        f.write("\n".join(compiled_yaml))
        
    print(f"\033[92m[✓] Successfully compiled {len(lines)} LSL lines to {len(compiled_yaml) * 6} YAML lines.\033[0m")
    print(f"[*] Output saved to: {os.path.basename(output_path)}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python lsl_compiler.py <script.lsl>")
        sys.exit(1)
        
    input_file = sys.argv[1]
    if not os.path.exists(input_file):
        print(f"Error: File '{input_file}' not found.")
        sys.exit(1)
        
    compile_file(input_file)