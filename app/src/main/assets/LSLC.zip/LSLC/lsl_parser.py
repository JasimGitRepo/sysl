import json
import re
from error_engine import ErrorEngine

class LSLParser:
    def __init__(self, syntax_file="lsl_syntax.json"):
        try:
            with open(syntax_file, 'r') as f:
                self.syntax_rules = json.load(f).get("commands", [])
        except Exception as e:
            print(f"Failed to load syntax file: {e}")
            exit(1)

    def parse_line(self, line, line_num):
        line = line.strip()
        if not line or line.startswith('#'):
            return ""

        # Extract the first word as the command keyword
        keyword = line.split()[0]
        
        # Find the syntax rule for this keyword
        rule = next((r for r in self.syntax_rules if r["keyword"] == keyword), None)
        
        if not rule:
            ErrorEngine.report(
                line_num, 
                "Syntax", 
                line, 
                f"Command '{keyword}' is not recognized. Please check documentation."
            )
            return None
            
        # Match against the exact regex pattern
        match = re.match(rule["pattern"], line)
        if not match:
            ErrorEngine.report(
                line_num, 
                "Format", 
                line, 
                f"Check syntax. Expected format:\n\t  {rule['format_help']}"
            )
            return None
            
        groups = match.groups()
        
        # Run specific Contextual Validations
        for val in rule.get("validations", []):
            val_group = groups[val["group_index"]]
            if val["condition"] == "required" and val_group is None:
                ErrorEngine.report(
                    line_num, 
                    val["error_type"], 
                    line, 
                    val["help"]
                )
                return None
                
        # Generate the YAML output
        yaml_out = []
        for template_line in rule["yaml_template"]:
            formatted_line = template_line
            
            # Replace {0}, {1}, or {1|fallback} with Regex Groups
            for i in range(len(groups)):
                val = groups[i]
                placeholder_pattern = r'\{' + str(i) + r'(?:\|([^}]+))?\}'
                
                def repl(m):
                    fallback = m.group(1) or ""
                    return val if val is not None else fallback
                    
                formatted_line = re.sub(placeholder_pattern, repl, formatted_line)
                
            yaml_out.append(formatted_line)
            
        return "\n".join(yaml_out)